#include "AuditableSnapshot.h"
std::string AuditableSnapshot::GetUsername() const {};
std::string AuditableSnapshot::date() const {};
std::string AuditableSnapshot::state() const {};
