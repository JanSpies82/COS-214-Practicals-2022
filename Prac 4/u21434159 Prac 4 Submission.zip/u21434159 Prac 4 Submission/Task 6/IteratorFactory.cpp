#include "IteratorFactory.h"
using namespace std;

IteratorFactory::IteratorFactory()
{
}

IteratorFactory::~IteratorFactory()
{
}