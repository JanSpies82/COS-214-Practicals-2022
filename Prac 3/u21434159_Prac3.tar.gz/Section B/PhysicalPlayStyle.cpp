#include "PhysicalPlayStyle.h"
using namespace std;

PhysicalPlayStyle::PhysicalPlayStyle(){};
PhysicalPlayStyle::~PhysicalPlayStyle(){};

string PhysicalPlayStyle::attack()
{
	return " is using physical ability to attack.";
}
