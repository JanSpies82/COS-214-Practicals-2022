#include "BattleState.h"
using namespace std;

BattleState::BattleState()
{
}

BattleState::~BattleState()
{
}

string BattleState::getBattleStyle()
{
	return this->battleStyle;
}
