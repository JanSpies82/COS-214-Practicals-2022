#include "AttackPlayStyle.h"
using namespace std;

AttackPlayStyle::AttackPlayStyle(){};
AttackPlayStyle::~AttackPlayStyle(){};

string AttackPlayStyle::attack()
{
	return " is attacking the opposing Pokemon.";
}
