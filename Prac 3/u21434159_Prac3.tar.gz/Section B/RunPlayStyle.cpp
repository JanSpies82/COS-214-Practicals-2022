#include "RunPlayStyle.h"
using namespace std;

RunPlayStyle::RunPlayStyle(){};
RunPlayStyle::~RunPlayStyle(){};

string RunPlayStyle::attack()
{
	return " decides life is better than death and leaves the battle.";
}
