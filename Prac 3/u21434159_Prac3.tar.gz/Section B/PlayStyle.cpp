#include "PlayStyle.h"
using namespace std;

PlayStyle::PlayStyle(){};
PlayStyle::~PlayStyle(){};

string PlayStyle::attack()
{
	return "";
}
