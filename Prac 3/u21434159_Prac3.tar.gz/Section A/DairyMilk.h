#ifndef DIARYMILK_H
#define DIARYMILK_H

#include "Chocolate.h"
class DairyMilk : public Chocolate
{
public:
	DairyMilk(bool slab);
	~DairyMilk();
};

#endif
