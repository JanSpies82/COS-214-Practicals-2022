#include "ConfectionaryFactory.h"
using namespace std;

ConfectionaryFactory::ConfectionaryFactory(){};
ConfectionaryFactory::~ConfectionaryFactory(){};
