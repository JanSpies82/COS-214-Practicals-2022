#ifndef MILKYBAR_H
#define MILKYBAR_H

#include "Chocolate.h"

class Milkybar : public Chocolate
{
public:
	Milkybar( bool slab);
	~Milkybar();
};

#endif
