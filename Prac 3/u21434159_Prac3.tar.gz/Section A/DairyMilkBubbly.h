#ifndef DAIRYMILKBUBLY_H
#define DAIRYMILKBUBLY_H

#include "AeratedChocolate.h"
class DairyMilkBubbly : public AeratedChocolate
{
public:
	DairyMilkBubbly(int bubblespccm);
	~DairyMilkBubbly();
};

#endif
