#ifndef LINDOR_H
#define LINDOR_H

#include "Chocolate.h"
class Lindor: public Chocolate
{

	public: Lindor(bool slab);
	~Lindor();
};

#endif
